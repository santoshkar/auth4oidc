package com.dbs.poc.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class AuthenticationTokenFilter implements Filter {

	@Autowired
	RestTemplate restTemplate;
	
	private static final Logger logger = LoggerFactory.getLogger(AuthenticationTokenFilter.class);

	@Override
	public void init(FilterConfig fc) throws ServletException {
		logger.info("Init AuthenticationTokenFilter");
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain fc) throws IOException, ServletException {
		SecurityContext context = SecurityContextHolder.getContext();
		System.out.println(req.getParameterNames());
		Enumeration<String> e = req.getParameterNames();
		while(e.hasMoreElements()) {
			System.out.println(e.nextElement()+" : "+req.getParameter(e.nextElement()));
		}
		if (context.getAuthentication() != null && context.getAuthentication().isAuthenticated()) {
			
			System.out.println(restTemplate);
			/**
			 * here you have to validate the token
			 */

			
			System.out.println("authenticated");
			HttpServletResponse httpRes = (HttpServletResponse) res;
			httpRes.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
	        PrintWriter writer = res.getWriter();
	        writer.println("HTTP Status 401 - " + "invalid token");
			return;
		} else {
			System.out.println("not authenticated");
		}

		fc.doFilter(req, res);
	}
}
